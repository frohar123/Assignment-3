# Image Upload Web App

A simple web application built with Node.js, Express, EJS, and Multer using ES modules (type: "module"). It allows users to upload images, view the latest uploaded image on the homepage, and browse all uploaded images in a gallery.

## Features

- Homepage displaying the latest uploaded image
- Image upload form supporting multiple image uploads
- Gallery page showing all uploaded images
- Stores image metadata (filename, path, original name, upload date) in a JSON file
- Basic error handling for file uploads
- Responsive design with minimal CSS

## Setup

1. Clone the repository:
   `bash
   git clone <repository-url>
   cd image-upload-app
