// Importing required modules which are already installed:
import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs-extra';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3001;

// Configure EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware to serve static files (CSS, images)
app.use(express.static(path.join(__dirname, 'public')));

// Ensure uploads directory exists
await fs.ensureDir(path.join(__dirname, 'public', 'uploads'));

// Ensure images.json exists
const imagesFilePath = path.join(__dirname, 'data', 'images.json');
if (!(await fs.exists(imagesFilePath))) {
    await fs.writeJson(imagesFilePath, []);
}

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});
const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        // Accept images only
        const filetypes = /jpeg|jpg|png|gif/;
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = filetypes.test(file.mimetype);
        if (extname && mimetype) {
            return cb(null, true);
        }
        cb(new Error('Only images are allowed (jpeg, jpg, png, gif)'));
    }
});

// Routes
// Homepage: Display the latest uploaded image
app.get('/', async (req, res) => {
    try {
        const images = await fs.readJson(imagesFilePath);
        // Get the most recent image
        const latestImage = images.length > 0 ? images[images.length - 1] : null;
        res.render('index', { latestImage });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Upload page: Render upload form
app.get('/upload', (req, res) => {
    res.render('upload', { error: null });
});

// Handle image upload (multiple images)
app.post('/upload', upload.array('images', 10), async (req, res) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.render('upload', { error: 'No files uploaded' });
        }

        const images = await fs.readJson(imagesFilePath);
        const newImages = req.files.map(file => ({
            filename: file.filename,
            path: `/uploads/${file.filename}`,
            name: file.originalname,
            uploadDate: new Date().toISOString()
        }));

        // Append new images to JSON file
        images.push(...newImages);
        await fs.writeJson(imagesFilePath, images);

        res.redirect('/');
    } catch (err) {
        console.error(err);
        res.render('upload', { error: 'Error uploading files' });
    }
});

// Gallery page: Display all uploaded images
app.get('/gallery', async (req, res) => {
    try {
        const images = await fs.readJson(imagesFilePath);
        res.render('gallery', { images });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        return res.render('upload', { error: 'Multer error: ' + err.message });
    } else if (err) {
        return res.render('upload', { error: err.message });
    }
    next();
});

// Start server
app.listen(port, () => {
    console.log("Server running at http://localhost:${port}");
});